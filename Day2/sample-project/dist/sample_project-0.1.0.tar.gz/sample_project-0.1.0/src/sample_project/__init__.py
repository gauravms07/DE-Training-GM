def greet(name:str):
    return f"Kimochii Yamete Kudasai {name}-kun"

